package hr.tvz.android.tasksonfirerep.model

data class BasicTask(
    val title: String,
    val description: String
)