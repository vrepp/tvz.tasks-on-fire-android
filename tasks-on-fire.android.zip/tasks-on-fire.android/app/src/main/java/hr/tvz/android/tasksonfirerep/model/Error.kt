package hr.tvz.android.tasksonfirerep.model

data class Error(
    val code: Int,
    val message: String
)