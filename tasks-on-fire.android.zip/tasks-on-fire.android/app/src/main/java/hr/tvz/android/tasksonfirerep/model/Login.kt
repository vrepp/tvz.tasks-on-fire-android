package hr.tvz.android.tasksonfirerep.model

data class Login(
    val username: String,
    val password: String)