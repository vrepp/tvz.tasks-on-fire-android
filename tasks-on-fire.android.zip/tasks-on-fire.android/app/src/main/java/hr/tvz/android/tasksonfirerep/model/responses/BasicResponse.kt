package hr.tvz.android.tasksonfirerep.model.responses;

data class BasicResponse (val message: String)