package hr.tvz.android.tasksonfirerep.model.responses

import hr.tvz.android.tasksonfirerep.model.Task

data class TaskListResponse(val tasks: List<Task>)