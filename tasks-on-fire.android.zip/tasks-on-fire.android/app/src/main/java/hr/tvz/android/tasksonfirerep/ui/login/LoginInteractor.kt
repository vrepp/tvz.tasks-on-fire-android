package hr.tvz.android.tasksonfirerep.ui.login

interface LoginInteractor {
    fun login(username: String, password: String)
}