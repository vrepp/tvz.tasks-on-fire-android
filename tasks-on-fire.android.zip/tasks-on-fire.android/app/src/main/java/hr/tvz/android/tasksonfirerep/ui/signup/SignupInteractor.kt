package hr.tvz.android.tasksonfirerep.ui.signup

interface SignupInteractor {
    fun signup(username: String, password: String)
}