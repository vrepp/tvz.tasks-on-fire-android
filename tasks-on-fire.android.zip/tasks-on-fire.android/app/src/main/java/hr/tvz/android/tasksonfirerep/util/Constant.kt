package hr.tvz.android.tasksonfirerep.util

const val SHARED_PREFERENCE_FILE = "tasksonfire"
const val SP_TOKEN = "token"
const val BASE_URL = "https://us-central1-tasksonfire-87be6.cloudfunctions.net/"